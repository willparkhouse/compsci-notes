import java.util.Arrays;
import java.text.DecimalFormat;

public class Student {
    private static final DecimalFormat df = new DecimalFormat("0.00");
    String name;
    String id;
    String[] modules;
    int[] marks;
    double average;

    public Student(String name){
        this.name = name;
        modules = new String[]{"OOP", "SWW1"};
        marks = new int[]{0,0};
        id = getId(name);
        //complete the constructor
    }

    public Student(String name, String[] modules, int[] marks){
        //complete the constructor
        this.name = name;
        this.modules = modules;
        this.marks = marks;
        id = getId(name);
        average = calculateAverage(marks);
    }

    public String getId (String name){
        //complete this method
        String[] temp = name.split(" ");
        String output = "";
        for(int i = 0; i < temp.length; i++){
            output = output.concat(String.valueOf(temp[i].charAt(0)));
        }
        output = output.toUpperCase().concat(String.valueOf(name.length()));
        return output;
    }

    public double calculateAverage(int[] marks){
        //complete this method
        double sum = 0;
        for (int value : marks){
            sum = sum + value;
        }
        double average = sum / marks.length;
        average = Double.parseDouble(df.format(average));
        return average;
    }

    public static double getAverage(Student[] students, String id){
        //complete this method
        double aver = 0;
        for(int i= 0; i < students.length; i++) {
            if (students[i].id.equals(id)) {
                aver = students[i].calculateAverage(students[i].marks);
            }
        }
        return aver;
    }

    public static int getMark(Student[] students, String id, String module) {
        //complete this method
        int mark = 0;
        for (int i = 0; i < students.length; i++) {
            if (students[i].id.equals(id)) {
                for(int j = 0; j < students[i].modules.length; j++){
                    if(students[i].modules[j].equals(module)){
                        mark = students[i].marks[j];
                    }
                }
            }
        }
        return mark;
    }
}
