public class Theatre {
    static int rows = 32;
    static int seatsPerRow = 20;
    static int bookedSeats = 456;
    static double ticketPrice = 25;
    static double expensesPerSeat = 2;

    public static void main (String[] args) {
        /*
        DO NOT CHANGE ANY LINES OF CODE IN main() USE THIS AS A GUIDE
         */
        double calculateMaxProfit = maxProfit(ticketPrice);
        double calculateProfit = profit(bookedSeats, ticketPrice);
        double lostProfit = lostProfit (calculateMaxProfit, calculateProfit);
        System.out.println("The lost profit is " + lostProfit);
    }

    static int capacity(int rows, int seatsPerRow) {//implement this method
        return rows * seatsPerRow;
    }

    static double expenses(double expensesPerSeat, int bookedSeats) {
        //implement this method

        return expensesPerSeat * bookedSeats;
    }

    static double income(int bookedSeats, double ticketPrice) {
        //implement this method
        return bookedSeats * ticketPrice;
    }

    static double profit(int bookedSeats, double ticketPrice) {
        //implement this method
        return income(bookedSeats, ticketPrice) - expenses(expensesPerSeat, bookedSeats);
    }

    static double maxProfit(double ticketPrice) {
        //implement this method
        return income(capacity(rows,seatsPerRow), ticketPrice) - expenses(expensesPerSeat,capacity(rows,seatsPerRow));
    }

    static double lostProfit(double maxProfit, double actualProfit) {
        double loss = maxProfit - actualProfit;
        return loss;
    }

}
