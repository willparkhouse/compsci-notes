public class StringCases {

    public static String camelCase(String inputString) {
        //complete this method
        inputString = inputString.replaceAll("[^a-zA-Z\\s]", "");
        String tempArr[];
        tempArr = inputString.split("\\s+");
        String output;
        output = tempArr[0].toLowerCase();
        int i;
        for(i = 1; i < tempArr.length; i++){
            String firstLetter = tempArr[i].substring(0, 1).toUpperCase();
            String restOfWord = tempArr[i].substring(1).toLowerCase();
            output = output.concat(firstLetter.concat(restOfWord));
        }
        return output;
    }

    public static String pascalCase(String inputString) {
        //complete this method
        inputString = inputString.replaceAll("[^a-zA-Z\\s]", "");
        String tempArr[];
        tempArr = inputString.split("\\s+");
        String pascalCaseOutput = "";
        int i;
        for(i = 0; i < tempArr.length; i++){
            String firstLetter = tempArr[i].substring(0, 1).toUpperCase();
            String restOfWord = tempArr[i].substring(1).toLowerCase();
            pascalCaseOutput = pascalCaseOutput.concat(firstLetter.concat(restOfWord));
        }
        return pascalCaseOutput;
    }

    public static String snakeCase(String inputString) {
        //complete this method
        inputString = inputString.replaceAll("[^a-zA-Z\\s]", "");
        String tempArr[];
        tempArr = inputString.split("\\s+");
        String snakeCaseOutput = tempArr[0].toLowerCase();
        int i;
        for(i = 1; i < tempArr.length; i++){
            snakeCaseOutput = snakeCaseOutput.concat("_");
            snakeCaseOutput = snakeCaseOutput.concat(tempArr[i].toLowerCase());
        }
        return snakeCaseOutput;
    }

    public static String screamingSnakeCase(String inputString) {
        //complete this method
        inputString = inputString.replaceAll("[^a-zA-Z\\s]", "");
        String tempArr[];
        tempArr = inputString.split("\\s+");
        String snakeCaseOutput = tempArr[0].toUpperCase();
        int i;
        for(i = 1; i < tempArr.length; i++){
            snakeCaseOutput = snakeCaseOutput.concat("_");
            snakeCaseOutput = snakeCaseOutput.concat(tempArr[i].toUpperCase());
        }
        return snakeCaseOutput;
    }

    public static String alternateCase(String inputString) {
        //complete this method
        inputString = inputString.replaceAll("[^a-zA-Z]", "");
        char charArr[] = inputString.toCharArray();
        String output = "";
        for(int i = 0; i < charArr.length; i++){
            if(i%2==0){
                charArr[i] = Character.toUpperCase(charArr[i]);
            }else{
                charArr[i] = Character.toLowerCase(charArr[i]);
            }

        }
        output = String.valueOf(charArr);
        return output;
    }
}
