public class BillingManager
{
    double vat;
    public BillingManager ()
    {
        vat = 0.2;

        //complete default constructor
    }
    public BillingManager (double vat)
    {
        this.vat = vat;
        //complete constructor
    }
    public double getVAT()
    {
        return vat;
    }

    public double computeBill(double amount)
    {
        //complete this method

        return amount * (1+vat);
    }

    public double computeBill(double amount, int quantity)
    {
        //complete this method
        return amount * (1+vat) * quantity;
    }
    public double computeBill(double amt, int quantity, double coupon)
    {
        //complete this method
        return ((amt * quantity) - coupon) * (1+vat) ;
    }

}