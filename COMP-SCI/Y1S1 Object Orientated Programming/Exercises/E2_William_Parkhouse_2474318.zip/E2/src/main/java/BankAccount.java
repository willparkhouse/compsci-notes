public class BankAccount {
    private String clientName;
    private int clientID;
    private double accountBalance;
    private boolean accClosed;

    public BankAccount(String clientName, int clientID, double accountBalance) {
        //implement the constructor
        this.clientName = clientName;
        this.clientID = clientID;
        this.accountBalance = accountBalance;
        accClosed = false;
    }

    public String getName() {
        //implement getter
        return clientName;
    }

    public int getID() {
        //implement getter
        return clientID;
    }

    public double getBalance() {
        //implement getter
        return accountBalance;
    }

    public boolean getClosed() {
        //implement getter
        return accClosed;
    }

    public void deposit(double depositAmount) {
        //implement this method
        accountBalance = accountBalance + depositAmount;
    }

    public void withdraw(double withdrawalAmount) {
        //implement this method
        accountBalance = accountBalance - withdrawalAmount;
    }

    public void closeAccount() {
        //implement this method
        accountBalance = 0;
        accClosed = true;
    }

    public void transferTo(BankAccount toAccount, double amount) {
        //implement this method
        toAccount.deposit(amount);
        withdraw(amount);
    }
}
