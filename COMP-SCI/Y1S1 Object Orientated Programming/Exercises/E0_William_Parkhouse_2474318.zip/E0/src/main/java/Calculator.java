//import static java.lang.Math;
public class Calculator {

    static int add(int a, int b) {
        int addResult = a + b;
        return addResult;
    }

    static float multiply(float a, float b) {
        float multiplyResult = a * b;
        return multiplyResult;
    }
    static int sub(int a, int b) {
        int subResult = a - b;
        return subResult;
    }

    static double div(double a, double b) {
        double divResult = a / b;
        return divResult;
    }

    static float circleArea(int radius) {
        float circleAreaResult = (float)Math.PI * (radius * radius);
        return circleAreaResult;
    }

    static double sphereVolume(float radius) {
        double sphereVolumeResult = (4/3)*Math.PI*radius*radius*radius;
        return sphereVolumeResult;
    }
}