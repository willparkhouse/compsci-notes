import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static java.lang.Double.POSITIVE_INFINITY;
import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    @Test
    @DisplayName("Add two numbers")
    void add() {
        assertAll(() -> assertEquals(-15, Calculator.add(-5, -10)),
                () -> assertEquals(5986, Calculator.add(128, 5858)));
    }

    @Test
    @DisplayName("Multiply two numbers")
    void multiply() {
        assertAll(() -> assertEquals(8.236499786376953, Calculator.multiply(2.55f, 3.23f)),
                  () -> assertEquals(-16, Calculator.multiply(4, -4)),
                  () -> assertEquals(26.5, Calculator.multiply(-5.3f, -5)),
                  () -> assertEquals(0, Calculator.multiply(7, 0)));
    }

    @Test
    @DisplayName("Subtract two numbers")
    void subtraction() {
        assertAll(() -> assertEquals(4, Calculator.sub(6, 2)),
                () -> assertEquals(-2, Calculator.sub(4, 6)),
                () -> assertEquals(0, Calculator.sub(-2, -2)),
                () -> assertEquals(63, Calculator.sub(63, 0)));
    }

    @Test
    @DisplayName("Divide two numbers")
    void division() {
        assertAll(() -> assertEquals(2.6, Calculator.div(6.5, 2.5)),
                () -> assertEquals(0.6666666666666666, Calculator.div(4.0, 6.0)),
                () -> assertEquals(1, Calculator.div(-2.0, -2.0)),
                () -> assertEquals(POSITIVE_INFINITY, Calculator.div(58, 0)));
    }

    @Test
    @DisplayName("Area of a circle")
    void circleArea() {
        assertAll(() -> assertEquals(78.5398178100586, Calculator.circleArea(5)),
                () -> assertEquals(1385.4423828125, Calculator.circleArea(21)),
                () -> assertEquals(804.2477416992188, Calculator.circleArea(16)),
                () -> assertEquals(12867.9638671875, Calculator.circleArea(64)));
    }

    @Test
    @DisplayName("Volume of a sphere")
    void sphereVolume() {
        assertAll(() -> assertEquals(16322.756907267229, Calculator.sphereVolume(17.32f)),
                () -> assertEquals(751.6316095319381, Calculator.sphereVolume(6.208f)),
                () -> assertEquals(392.69908169872417, Calculator.sphereVolume(5)),
                () -> assertEquals(1096.1445857407766, Calculator.sphereVolume(7.04f)));
    }
}