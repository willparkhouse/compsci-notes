public class Goblin extends Creature {
    final int DISTANCEOFATTACK = 3;
    public Goblin(int posX, int posY){
        this.posX = posX;
        this.posY = posY;
        health = 80;
        power = 15;
    }

    @Override
    public boolean isInRange(int targetPosX, int targetPosY) {
        if(Math.sqrt(Math.pow((Math.abs(targetPosX - super.posX)), 2)+Math.pow(Math.abs(targetPosY - super.posY), 2))<= DISTANCEOFATTACK){
            return true;
        } else {
            return false;
        }
    }
}
