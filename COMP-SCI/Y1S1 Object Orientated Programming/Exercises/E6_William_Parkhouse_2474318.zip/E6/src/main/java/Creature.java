public abstract class Creature {
    int posX;
    int posY;
    int health;
    int power;

    public void attack(Creature c){
        if(isInRange(c.posX, c.posY)) {
            c.health = c.health - power;
        }
    }

    public abstract boolean isInRange(int targetPosX, int targetPosY);

    public void move (int x, int y){
        posX = posX + x;
        posY = posY +y;
        //complete this method
    }

    public boolean isDefeated (){
        if (health <= 0) {
            return true;
        } else {
            return false;
        }
    }
}
