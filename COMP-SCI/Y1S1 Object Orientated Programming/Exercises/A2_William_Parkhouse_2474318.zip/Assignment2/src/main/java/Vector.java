public class Vector {
    private final double[] doubElements;

    public Vector(double[] _elements) {
        //TODO Task 1.1
        doubElements = _elements;
    }

    public double getElementatIndex(int _index) {
        //TODO Task 1.2
        try{
            return doubElements[_index];
        } catch (ArrayIndexOutOfBoundsException e) {
            return -1;
        }
    }

    public void setElementatIndex(double _value, int _index) {
        //TODO Task 1.3
        try{
            doubElements[_index] = _value;
        } catch (ArrayIndexOutOfBoundsException e) {
            doubElements[doubElements.length - 1] = _value;
        }
    }

    public double[] getAllElements() {
        //TODO Task 1.4
        return doubElements;
    }

    public int getVectorSize() {
        //TODO Task 1.5
        return doubElements.length;
    }

    public Vector reSize(int _size) {
        //TODO Task 1.6
        Vector thisVector = new Vector(doubElements);
        Vector newVector = null;
        if (_size == doubElements.length || _size <= 0) {
            return thisVector;
        } else if (_size < doubElements.length) {
            double[] newArray = new double[_size];
            System.arraycopy(doubElements, 0, newArray, 0, _size);
            newVector = new Vector(newArray);
        } else if (_size > doubElements.length) {
            double[] newArray = new double[_size];
            for(int i = 0; i < newArray.length; i++) {
                newArray[i] = -1;
            }
            System.arraycopy(doubElements, 0, newArray, 0, doubElements.length);
            newVector = new Vector(newArray);
        }
        return newVector;
    }

    public Vector add(Vector _v) {
        //TODO Task 1.7
        Vector oBuffer;
        Vector iBuffer;
        if(_v.getVectorSize() > this.getVectorSize()){
            iBuffer = this.reSize(_v.getVectorSize());
            oBuffer = _v;
        } else if(_v.getVectorSize() < this.getVectorSize()) {
             oBuffer = _v.reSize(this.getVectorSize());
             iBuffer = this;
        } else{
            oBuffer = _v;
            iBuffer = this;
        }
        double[] addedDoubles = new double[iBuffer.getVectorSize()];
        double[] thisDoubs = iBuffer.getAllElements();
        double[] vDoubs = oBuffer.getAllElements();
        for(int i = 0; i < iBuffer.getVectorSize(); i++){
            addedDoubles[i] = vDoubs[i] + thisDoubs[i];
        }
        return new Vector(addedDoubles);
    }

    public Vector subtraction(Vector _v) {
        //TODO Task 1.8
        Vector oBuffer;
        Vector iBuffer;
        if(_v.getVectorSize() > this.getVectorSize()){
            iBuffer = this.reSize(_v.getVectorSize());
            oBuffer = _v;
        } else if(_v.getVectorSize() < this.getVectorSize()) {
            oBuffer = _v.reSize(this.getVectorSize());
            iBuffer = this;
        } else{
            oBuffer = _v;
            iBuffer = this;
        }
        double[] addedDoubles = new double[iBuffer.getVectorSize()];
        double[] thisDoubs = iBuffer.getAllElements();
        double[] vDoubs = oBuffer.getAllElements();
        for(int i = 0; i < iBuffer.getVectorSize(); i++){
            addedDoubles[i] =  thisDoubs[i] - vDoubs[i];
        }
        return new Vector(addedDoubles);
    }

    public double dotProduct(Vector _v) {
        //TODO Task 1.9
        Vector oBuffer;
        Vector iBuffer;
        if(_v.getVectorSize() > this.getVectorSize()){
            iBuffer = this.reSize(_v.getVectorSize());
            oBuffer = _v;
        } else if(_v.getVectorSize() < this.getVectorSize()) {
            oBuffer = _v.reSize(this.getVectorSize());
            iBuffer = this;
        } else{
            oBuffer = _v;
            iBuffer = this;
        }
        double[] thisDoubs = iBuffer.getAllElements();
        double[] vDoubs = oBuffer.getAllElements();
        double dotProd = 0;
        for(int i = 0; i < iBuffer.getVectorSize(); i++){
            dotProd =  dotProd + (thisDoubs[i] * vDoubs[i]);
        }
        return dotProd;
    }

    public double cosineSimilarity(Vector _v) {
        //TODO Task 1.10
        Vector oBuffer;
        Vector iBuffer;
        if(_v.getVectorSize() > this.getVectorSize()){
            iBuffer = this.reSize(_v.getVectorSize());
            oBuffer = _v;
        } else if(_v.getVectorSize() < this.getVectorSize()) {
            oBuffer = _v.reSize(this.getVectorSize());
            iBuffer = this;
        } else{
            oBuffer = _v;
            iBuffer = this;
        }
        double[] thisDoubs = iBuffer.getAllElements();
        double[] vDoubs = oBuffer.getAllElements();
        double dotProd = this.dotProduct(_v);
        double cosSim = 0;
        double vSquareSum = 0;
        double uSquareSum = 0;
        for(int i = 0; i < iBuffer.getVectorSize(); i++){
            vSquareSum =  vSquareSum + Math.pow(thisDoubs[i], 2);
            uSquareSum =  uSquareSum + Math.pow(vDoubs[i], 2);
        }
        cosSim = (dotProd) / ((Math.sqrt(vSquareSum)) * (Math.sqrt(uSquareSum)));
        return cosSim;
    }

    @Override
    public boolean equals(Object _obj) {
        Vector v = (Vector) _obj;
        boolean boolEquals = true;
        if(this.getVectorSize() != v.getVectorSize()){
            boolEquals = false;
        }
        try {
            for (int i = 0; this.getVectorSize() > i; i++){
                if(doubElements[i] != v.getElementatIndex(i)){
                    boolEquals = false;
                }
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            boolEquals = false;
        }
        return boolEquals;
    }


    @Override
    public String toString() {
        StringBuilder mySB = new StringBuilder();
        for (int i = 0; i < this.getVectorSize(); i++) {
            mySB.append(String.format("%.5f", doubElements[i])).append(",");
        }
        mySB.delete(mySB.length() - 1, mySB.length());
        return mySB.toString();
    }
}
