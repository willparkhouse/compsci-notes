public class Glove {
    private String strVocabulary;
    private Vector vecVector;

    public Glove(String _vocabulary, Vector _vector) {
        //TODO Task 2.1
        strVocabulary = _vocabulary;
        vecVector = _vector;
    }

    public String getVocabulary() {
        return strVocabulary;
    }

    public void setVocabulary(String strVocabulary) {
        this.strVocabulary = strVocabulary;
    }

    public Vector getVector() {
        return vecVector;
    }

    public void setVector(Vector vecVector) {
        this.vecVector = vecVector;
    }
}
